export const Input = (props) => <input {...props} className='border px-2 py-1 rounded' />;
